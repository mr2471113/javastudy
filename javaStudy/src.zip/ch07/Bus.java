package ch07;

public class Bus extends Car {
	char color = 'R';

	Bus() {
		System.out.println("SportsCar ��ü ����");
	}
	
	void load() {
		System.out.println("ž��");
	}

}