package ch05;

public class Array1 {

	public static void main(String[] args) {
		int[] s = new int[3];
		
		for(int i = 0; i < s.length; i++) {
			System.out.println(s[i]);
		}
	}
}
