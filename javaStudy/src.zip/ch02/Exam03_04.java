package ch02;

public class Exam03_04 {
	public static void main(String[] args) {
		int num = 111;
		System.out.println(num/100*100);
	}
}
