package ch02;

public class Exam02_1 {
	public static void main(String[] args) {
		boolean isFun = false;
		char charValue = 'a';
		int intValue = 20;
		long longValue = 2147483648L;
		
	System.out.println(isFun);
	System.out.println(charValue);
	System.out.println(intValue);
	System.out.println(longValue);
	}
}
